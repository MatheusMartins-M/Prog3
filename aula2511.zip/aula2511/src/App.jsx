import "./App.css"
import Contatos from "./Contatos"

function App() {
  return (
    <>
      <Contatos/>
    </>
  )
}

export default App