import { useState } from "react"

export default function Contato({onEnvio}){
    //
    //const {onEvento} = props;
    //const onEvento = props.onEvento;


    const [nome, setNome] = useState("");
    const [email, setEmail] = useState("");

    function enviar(event){
        event.preventDefault();
        const novoContato ={nome:nome, email:email};
        onEnvio(novoContato);
    }

    return <form onSubmit={enviar}>
        <label>Nome: </label>
        <input value = {nome}
               onChange={(event) => setNome(event.target.value)}/>
        <label> E-mail: </label>
        <input type="email" 
               value ={email}
               onChange={(event)=> setEmail(event.target.value)}/>
               <button>Enviar</button>
    </form>
}