import axios from "axios"
import { useEffect } from "react"
import { useState } from "react"
import Contato from "./Contato"

export default function Contatos(){
    const [contatos, setContatos] = useState([])
    
    async function recuperaContatos(){
        const resposta = await axios.get('https://66f876042a683ce9730f831d.mockapi.io/contatos');
        setContatos(resposta.data);
    }

    async function excluirContato(contato) {
        if(window.confirm("Excluir "+ contato.nome +"?")){
            axios.delete("https://66f876042a683ce9730f831d.mockapi.io/contatos/"+ contato.id);

            const novaListaContatos = contatos.filter(
                contatoDaLista => contatoDaLista.id != contato.id);

            setContatos(novaListaContatos)
        }
    }

    async function cadastrar(contato){
        console.log("contato");
        console.log(contato);
        const retorno = await axios.post('https://66f876042a683ce9730f831d.mockapi.io/contatos', contato);
        
        console.log(retorno.data)
        const novaListaContatos = [...contatos, retorno.data]

        setContatos(novaListaContatos);

    }

    useEffect(() => {recuperaContatos()}, []);

    console.log("Estado contatos");
    console.log(contatos)

    

    return <>
    <Contato onEnvio={cadastrar} />
    <br/>
    <table border = "1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>E-mail</th>
            </tr>
        </thead>
        <tbody>
            {contatos.map(contato => <tr key={contato.id}>
                <td>{contato.id}</td>
                <td>{contato.nome}</td>
                <td>{contato.email}</td>
                <td><button>Editar</button></td>
                <td><button onClick={()=>excluirContato(contato)}>Excluir</button></td>
                </tr>)}
        </tbody>
    </table>
    </>
}