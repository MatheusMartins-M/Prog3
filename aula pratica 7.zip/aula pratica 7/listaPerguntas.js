export default [
    {
      "id": 1,
      "pergunta": "A Água ferve a 100°C ao ní­vel do mar.",
      "resposta": true
    },
    {
      "id": 2,
      "pergunta": "O Sol gira em torno da Terra.",
      "resposta": false
    },
    {
      "id": 3,
      "pergunta": "Os seres humanos têm 32 dentes permanentes.",
      "resposta": true
    },
    {
      "id": 4,
      "pergunta": "Um quilômetro tem 500 metros.",
      "resposta": false
    },
    {
      "id": 5,
      "pergunta": "O elemento quí­mico do ouro é Au.",
      "resposta": true
    },
    {
      "id": 6,
      "pergunta": "A Lua é um planeta.",
      "resposta": false
    },
    {
      "id": 7,
      "pergunta": "As baleias são mamí­feros.",
      "resposta": true
    },
    {
      "id": 8,
      "pergunta": "O Brasil faz fronteira com a Rússia.",
      "resposta": false
    },
    {
      "id": 9,
      "pergunta": "A vitamina C é encontrada em frutas cí­tricas.",
      "resposta": true
    },
    {
      "id": 10,
      "pergunta": "O número pi é aproximadamente 3,14.",
      "resposta": true
    }
  ];