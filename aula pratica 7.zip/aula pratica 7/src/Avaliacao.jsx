import React, { useState } from "react";
import Questao from "./Questao";

export default function Avaliacao(props){
  const [listaPerguntas, setListaPerguntas] = useState([...props.listaPerguntas]);
  const atualizaValorResposta = (id, acertou) => {
    const listaAtualizada = listaPerguntas.map(pergunta =>{
      if(id === pergunta.id){
        pergunta.acertou = acertou;
        return pergunta;
      }else{
        return pergunta;
      }
    });
    setListaPerguntas(listaAtualizada);
  }
  const acertos = listaPerguntas.filter(pergunta => pergunta.acertou===true)
  const erros = listaPerguntas.filter(pergunta => pergunta.acertou===false)
  const naoRespondeu = listaPerguntas.filter(pergunta => pergunta.acertou===undefined)

  return ( <div>
      {listaPerguntas.map(
        (pergunta)=>
        <Questao 
          onRespondeu={(acertou) => atualizaValorResposta(pergunta.id, acertou)}
          questao={pergunta.pergunta}
          resposta={pergunta.resposta} 
        />
      )}
      
      <h2>RESUMO</h2>
      Acertos: {acertos.length} <br/>
      Erros: {erros.length} <br/>
      Não respondeu: {naoRespondeu.length} <br/>
      Média: {acertos.length / listaPerguntas.length}
    </div>
  )
}