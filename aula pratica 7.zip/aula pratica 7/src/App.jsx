import React from "react"
import Avaliacao from "./Avaliacao"
import listaPerguntas from "../listaPerguntas"

function App() {
  return <Avaliacao listaPerguntas = {listaPerguntas}/>
}

export default App
