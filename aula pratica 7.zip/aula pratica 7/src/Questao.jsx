import React, { useState } from "react";

export default function Questao(props) {
    const [jaRespondeu, setJaRespondeu] = useState(false);
    const [resultado, setResultado] = React.useState("Não respondeu");

    function teste(resposta) {
        setJaRespondeu(true);
        if(resposta===props.resposta) {
            setResultado("acertou!");
            props.onRespondeu(true);
        } else {
            setResultado("Errouuu!");
            props.onRespondeu(false);
        }
        
    }
    
    return (
        <div>{props.questao} <br/> <br/>
            <button disabled ={jaRespondeu} onClick={() => teste(true)}>Verdadeiro</button>
            <button disabled ={jaRespondeu} onClick={() => teste(false)}>Falso</button>
            <br/>
            Resposta: {resultado}
            <hr></hr>
    </div>)
}