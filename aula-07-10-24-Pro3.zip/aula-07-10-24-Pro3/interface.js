import aqueleQueLe from 'readline-sync';

export default function lerTexto(texto){
    return aqueleQueLe.question(texto);
}

