import fetch from "node-fetch";

export default async function busca(url){
    const retornoDoServidor = await fetch(url);
    const json = await retornoDoServidor.json();
    return json;
}