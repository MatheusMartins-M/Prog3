import fetch from "node-fetch";
import buscar from "fetchJson.js"

/*async function buscaDados(){
    const retornoDoServidor = await fetch('https://66f876042a683ce9730f831d.mockapi.io/pessoas');
    //console.log(retornoDoServidor);

    const retornoTratado = await retornoDoServidor.json();
    console.log(retornoTratado);
}*/

console.log("Vou chamar buscaDados");
console.log("Chamei buscaDados");
buscar('https://66f876042a683ce9730f831d.mockapi.io/pessoas');