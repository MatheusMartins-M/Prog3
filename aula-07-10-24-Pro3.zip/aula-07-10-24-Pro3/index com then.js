
//npm init -> iniciar package
//adicionar abaixo do main "type": "module",
// "as" serve pra apelidar as funções caso estejam muito grandes ou por pura vontade mesmo
//npm install readline-sync -s
//npm install node-fetch    -> recuperação de dados do servidor

//funções não apelidadas
//import {divisao multiplicacao, PI, soma, subtracao} from './operacao.js';

//funções apelidadas
//import {divisao as div, multiplicacao as multi, PI, soma, subtracao as sub} from './operacao.js';

//puxar tudo que existe na biblioteca
import * as operacao from './operacao.js';

//padrão
//import lerTexto from './interface.js';

//pode ser trocado o nome por ser default
import leitorDeTexto from './interface.js';
import fetch from 'node-fetch';


console.log("Aula 07/10");
console.log();

console.log("Teste soma -> ", operacao.soma(4, 5));
console.log("Teste sub -> ", operacao.subtracao(10, 5));
console.log("Teste multi -> ", operacao.multiplicacao(132, 3));
console.log("Teste div -> ", operacao.divisao(26, 2));
console.log("Teste PI -> ", operacao.PI);

const retorno = fetch('https://66f876042a683ce9730f831d.mockapi.io/pessoas');

retorno.then(function(retornoDoServidor){
    console.log("Servidor retornou:");
    const retornoFormatado = retornoDoServidor.json();
    console.log(retornoFormatado)
    retornoFormatado.then(function(retornoEmJson){
        console.log("Retornando em json: ")
        console.log(retornoEmJson)
    })
});
console.log(retorno);

