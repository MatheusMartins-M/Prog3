export function soma(a, b){
    return a + b;
}

export function subtracao(a, b){
    return a - b;
}

export function multiplicacao(a, b){
    return a * b;
}

export function divisao(a, b){
    return a / b;
}

export const PI = 3.14;