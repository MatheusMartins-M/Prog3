function aviso(){
  alert("Você está errado");
}

function Botao(props){
  console.log(props.texto)
  return <button onClick={aviso} > {props.texto} </button>
}

function App() {
  return (
    <div>
    <h1> AULA PROG 3 </h1>
    <h2> | Começando os trabalhos | </h2>
    
    Texto
    <br/>
      <label>Campo: </label> <input />
      <button>ADD</button> <br></br>
      

      <Botao texto = "Aviso!"/> <br></br>
      <Botao texto = "Erro!"/> <br></br>
      <Botao texto = "Dica!"/> <br></br>

          
    </div>
  )
}

export default App
