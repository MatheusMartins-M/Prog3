//npm init vite ou npm create vite@latest
