import React, { useState } from "react";
import Tecla from "./Tecla";

function Cofre(senha){
    const [tentativas, setTentativas] = useState(3)
    const senhaEmArray = senha.split("").map(valor => Number(valor))

    

    return(
        <div>

        </div>
    );
}
export default Cofre;