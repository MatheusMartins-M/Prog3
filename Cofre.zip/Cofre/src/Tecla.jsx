import React, { useState } from "react";

function Tecla(){
    const [valor, setValor] = useState[0];
    const incrementa = () => {setValor(valor + 1)}
    const decrementa = () => {setValor(valor - 1)}

    if(valor > 9){
        setValor = 0
    }else if(valor < 0){
        setValor = 9
    }
    
    return(
        <div>
            <button onClick={() => incrementa}>+</button>
            {valor}
            <button onClick={() => decrementa}>-</button>

        </div>
    );

}

export default Tecla;