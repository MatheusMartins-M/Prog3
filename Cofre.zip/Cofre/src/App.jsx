import Cofre from './Cofre'

function App() {
  return (
    <>  
    <Cofre senha="1234" /> 
    </>
  )
}

export default App
